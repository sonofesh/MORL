
Authors
=======

* Ionel Cristian Mărieș - https://blog.ionelmc.ro
* Marc Abramowitz - http://marc-abramowitz.com
* Dave Collins - https://github.com/thedavecollins
* Stefan Krastanov - http://blog.krastanov.org
* Thomas Waldmann - https://github.com/ThomasWaldmann
* Antonio Cuni - http://antocuni.eu
* Petr Šebek - https://github.com/Artimi
* Swen Kooij - https://github.com/Photonios
* "varac" - https://github.com/varac
* Andre Bianchi - https://github.com/drebs
* Jeremy Dobbins-Bucklad - https://github.com/jad-b
* Alexey Popravka - https://github.com/popravich
* Ken Crowell - https://github.com/oeuftete
* Matthew Feickert - https://github.com/matthewfeickert
* Julien Nicoulaud - https://github.com/nicoulaj
* Pablo Aguiar - https://github.com/scorphus
* Alex Ford - https://github.com/asford
* Francesco Ballarin - https://github.com/francesco-ballarin
* Lincoln de Sousa - https://github.com/clarete
* Jose Eduardo - https://github.com/JoseKilo
* Ofek Lev - https://github.com/ofek
* Anton Lodder - https://github.com/AnjoMan
* Alexander Duryagin - https://github.com/daa
* Stanislav Levin - https://github.com/stanislavlevin
* Grygorii Iermolenko - https://github.com/gyermolenko
* Jonathan Simon Prates - https://github.com/jonathansp
* Miroslav Šedivý - https://github.com/eumiro
* Dimitris Rozakis - https://github.com/dimrozakis
* Friedrich Delgado - https://github.com/TauPan
* Sam James - https://github.com/thesamesam
* Florian Bruhin - https://github.com/The-Compiler
