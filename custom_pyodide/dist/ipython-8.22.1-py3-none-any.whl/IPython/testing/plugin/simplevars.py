x = 1
print("x is:", x)
